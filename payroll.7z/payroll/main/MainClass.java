package com.cg.payroll.main;

import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass{
	
	public static void main(String[] args) {
		
		PayrollServicesImpl payrollServices = new PayrollServicesImpl();
		System.out.println(payrollServices.acceptAssociateDetails(400000, "Samykya", "Thanuku", "Java", "Analyst", "BCPO1234", "Sam@gmail.com", 123654, "CITI", "CITI00005", 50000, 1000, 1000));
		System.out.println(payrollServices.getAssociateDetails(111).getFirstName()+" "+payrollServices.getAssociateDetails(111).getLastName());
		System.out.println(payrollServices.caluculateNetSalary(111));
		System.out.println(payrollServices.getAssociateDetails(111).getSalary().getBasicSalary());
	}

}