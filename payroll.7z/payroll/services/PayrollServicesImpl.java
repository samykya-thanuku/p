package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {
	private PayrollDAOServicesImpl daoServices;
	private float annualTax;
	public PayrollServicesImpl() {
		daoServices=new PayrollDAOServicesImpl();
	}

	public int acceptAssociateDetails(int yearlyInvestmentUnder80C, String firstName, String lastName,
			String department, String designation, String pancard, String emailId,int accountNumber, String bankName, String ifscCode,int basicSalary,int epf, int companyPf){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	public float caluculateNetSalary(int associateId){
		Associate associate = getAssociateDetails(associateId);
		if(associate!=null){
			//Associate associate = this.getAssociateDetails(associateId);
	
			associate.getSalary().setPersonalAllowance(0.3f*associate.getSalary().getBasicSalary());
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGratuity(0.05f*associate.getSalary().getBasicSalary());
			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getCompanyPf()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getHra());
			float annualSalary=12*associate.getSalary().getGrossSalary();
			if((associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary().getCompanyPf())+(12*associate.getSalary().getEpf())<=150000)) {
				if(annualSalary>=1000000) {
					annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getCompanyPf())-(12*associate.getSalary().getEpf()));
				}
				else if(annualSalary>=500000&&annualSalary<100000) 
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*(150000-(associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getEpf()+12*associate.getSalary().getCompanyPf())))));
				else if(annualSalary<500000 && annualSalary>=250000)
					if(annualSalary-250000>(associate.getYearlyInvestmentUnder80C()+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf()))
						annualTax=0.1f*(annualSalary-250000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary().getEpf()-12*associate.getSalary().getCompanyPf()));
					else 
						annualTax=0;
				else if(annualSalary<250000)
					annualTax=0;
			}
			else {
				if(annualSalary>=1000000) 
					annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
				else if(annualSalary>=500000&&annualSalary<100000)
					annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
				else if(annualSalary<500000 && annualSalary>=250000)
					annualTax=(0.1f*(100000));
				else
					annualTax=0;
			}
			associate.getSalary().setMonthlyTax(annualTax/12);
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf());
	return associate.getSalary().getNetSalary();
				
			}
	return 0;
	}
	public Associate getAssociateDetails(int associateId){
		return daoServices.getAssociate(associateId);

	}
	public Associate[]getAssociatesDetails(){
		return null;
	}

}
